/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

import Controlador.LoginController;
import Vista.FrmLogin;

public class Main {

    public static void main(String[] args) {
        
        FrmLogin login = new FrmLogin();
        
        LoginController controller = new LoginController(login);
        
        controller.iniciar();
        
    }
}
