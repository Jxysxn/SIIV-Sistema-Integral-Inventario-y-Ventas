/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.DetalleCompra;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DetalleCompraDAO {

    Connection con;
    CallableStatement cs;
    PreparedStatement ps;
    ResultSet rs;

    // Registrar detalle usando SP y credenciales del usuario actual
    public void registrarDetalle(DetalleCompra d, Usuario usuario) {
        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            cs = con.prepareCall("{CALL sp_registrar_detalle_compra(?, ?, ?, ?)}");
            cs.setInt(1, d.getIdCompra());
            cs.setInt(2, d.getIdProducto());
            cs.setInt(3, d.getCantidad());
            cs.setDouble(4, d.getPrecioUnitario());
            cs.execute();

        } catch (Exception e) {
            System.out.println("Error registrar detalle: " + e.getMessage());
        }
    }

    // Listar detalle por compra
    public List<DetalleCompra> listarPorCompra(int idCompra, Usuario usuario) {
        List<DetalleCompra> lista = new ArrayList<>();
        String sql = "SELECT p.nombre AS producto, dc.cantidad, dc.precioUnitario, dc.subtotal "
                + "FROM DetalleCompra dc "
                + "INNER JOIN Producto p ON dc.idProducto = p.idProducto "
                + "WHERE dc.idCompra = ?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, idCompra);
            rs = ps.executeQuery();

            while (rs.next()) {
                DetalleCompra d = new DetalleCompra();
                d.setNombreProducto(rs.getString("producto"));
                d.setCantidad(rs.getInt("cantidad"));
                d.setPrecioUnitario(rs.getDouble("precioUnitario"));
                d.setSubtotal(rs.getDouble("subtotal"));
                lista.add(d);
            }

        } catch (Exception e) {
            System.out.println("Error listar detalle: " + e.getMessage());
        }
        return lista;
    }

}
