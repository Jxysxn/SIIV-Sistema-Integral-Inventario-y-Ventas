/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Cliente;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // LISTAR CLIENTES
    public List<Cliente> listar(Usuario usuario) {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM Cliente";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();
                c.setIdCliente(rs.getInt("idCliente"));
                c.setNombre(rs.getString("nombre"));
                c.setDocumento(rs.getString("documento"));
                c.setTelefono(rs.getString("telefono"));
                c.setCorreo(rs.getString("correo"));
                c.setDireccion(rs.getString("direccion"));
                c.setEstado(rs.getString("estado"));
                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error al listar clientes: " + e.getMessage());
        }
        return lista;
    }

    // INSERTAR CLIENTE
    public boolean insertar(Cliente c, Usuario usuario) {
        String sql = "INSERT INTO Cliente (nombre, documento, telefono, correo, direccion, estado) VALUES (?, ?, ?, ?, ?, ?)";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDocumento());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getCorreo());
            ps.setString(5, c.getDireccion());
            ps.setString(6, c.getEstado());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al insertar cliente: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR CLIENTE
    public boolean actualizar(Cliente c, Usuario usuario) {
        String sql = "UPDATE Cliente SET nombre=?, documento=?, telefono=?, correo=?, direccion=?, estado=? WHERE idCliente=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDocumento());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getCorreo());
            ps.setString(5, c.getDireccion());
            ps.setString(6, c.getEstado());
            ps.setInt(7, c.getIdCliente());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al actualizar cliente: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR CLIENTE
    public boolean eliminar(int id, Usuario usuario) {
        String sql = "DELETE FROM Cliente WHERE idCliente=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al eliminar cliente: " + e.getMessage());
            return false;
        }
    }

    // Buscar clientes
    public List<Cliente> buscar(String texto, Usuario usuario) {
        List<Cliente> lista = new ArrayList<>();

        String sql = "SELECT * FROM Cliente WHERE nombre LIKE ? OR documento LIKE ? OR telefono LIKE ? OR correo LIKE ? OR direccion LIKE ? OR estado LIKE ?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);

            for (int i = 1; i <= 6; i++) {
                ps.setString(i, "%" + texto + "%");
            }

            rs = ps.executeQuery();

            while (rs.next()) {
                Cliente c = new Cliente();
                c.setIdCliente(rs.getInt("idCliente"));
                c.setNombre(rs.getString("nombre"));
                c.setDocumento(rs.getString("documento"));
                c.setTelefono(rs.getString("telefono"));
                c.setCorreo(rs.getString("correo"));
                c.setDireccion(rs.getString("direccion"));
                c.setEstado(rs.getString("estado"));
                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error buscar clientes: " + e.getMessage());
        }
        return lista;
    }

}
