/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Categoria;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // LISTAR CATEGORIAS
    public List<Categoria> listar(Usuario usuario) {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM Categoria";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Categoria c = new Categoria();
                c.setIdCategoria(rs.getInt("idCategoria"));
                c.setNombre(rs.getString("nombre"));
                c.setDescripcion(rs.getString("descripcion"));
                c.setEstado(rs.getString("estado"));
                lista.add(c);
            }
        } catch (Exception e) {
            System.out.println("Error al listar categoría: " + e.getMessage());
        }
        return lista;
    }

    // INSERTAR
    public boolean insertar(Categoria c, Usuario usuario) {
        String sql = "INSERT INTO Categoria (nombre, descripcion, estado) VALUES (?, ?, ?)";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDescripcion());
            ps.setString(3, c.getEstado());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR
    public boolean actualizar(Categoria c, Usuario usuario) {
        String sql = "UPDATE Categoria SET nombre=?, descripcion=?, estado=? WHERE idCategoria=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, c.getNombre());
            ps.setString(2, c.getDescripcion());
            ps.setString(3, c.getEstado());
            ps.setInt(4, c.getIdCategoria());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al actualizar categoría: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR
    public boolean eliminar(int id, Usuario usuario) {
        String sql = "DELETE FROM Categoria WHERE idCategoria=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al eliminar categoría: " + e.getMessage());
            return false;
        }
    }

    // OBTENER NOMBRE CATEGORIA POR ID
    public String obtenerNombreCategoria(int id, Usuario usuario) {
        String nombre = "";
        String sql = "SELECT nombre FROM Categoria WHERE idCategoria=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                nombre = rs.getString("nombre");
            }

        } catch (Exception e) {
            System.out.println("Error obtener nombre categoría: " + e.getMessage());
        }
        return nombre;
    }

// OBTENER ID CATEGORIA POR NOMBRE
    public int obtenerIdCategoria(String nombre, Usuario usuario) {
        int id = 0;
        String sql = "SELECT idCategoria FROM Categoria WHERE nombre=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt("idCategoria");
            }

        } catch (Exception e) {
            System.out.println("Error obtener id categoría: " + e.getMessage());
        }
        return id;
    }

    // BUSCAR CATEGORIAS
    public List<Categoria> buscar(String texto, Usuario usuario) {
        List<Categoria> lista = new ArrayList<>();
        String sql = "SELECT * FROM Categoria WHERE nombre LIKE ? OR descripcion LIKE ? OR estado LIKE ?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);

            for (int i = 1; i <= 3; i++) {
                ps.setString(i, "%" + texto + "%");
            }

            rs = ps.executeQuery();

            while (rs.next()) {
                Categoria c = new Categoria();
                c.setIdCategoria(rs.getInt("idCategoria"));
                c.setNombre(rs.getString("nombre"));
                c.setDescripcion(rs.getString("descripcion"));
                c.setEstado(rs.getString("estado"));
                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error buscar categoría: " + e.getMessage());
        }
        return lista;
    }

}
