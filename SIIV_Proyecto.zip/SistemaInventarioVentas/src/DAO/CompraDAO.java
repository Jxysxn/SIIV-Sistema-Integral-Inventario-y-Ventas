/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Compra;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CompraDAO {

    Connection con;
    PreparedStatement ps;
    CallableStatement cs;
    ResultSet rs;

    // REGISTRAR COMPRA (SP)
    public int registrarCompra(int idProveedor, int idUsuario, Usuario usuario) {
        int idGenerado = 0;

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            cs = con.prepareCall("{CALL sp_registrar_compra(?, ?, ?)}");
            cs.setInt(1, idProveedor);
            cs.setInt(2, idUsuario);
            cs.registerOutParameter(3, java.sql.Types.INTEGER);

            cs.execute();
            idGenerado = cs.getInt(3);

        } catch (Exception e) {
            System.out.println("Error registrar compra: " + e.getMessage());
        }
        return idGenerado;
    }

    // LISTAR COMPRAS GENERAL
    public List<Compra> listarCompras(Usuario usuario) {
        List<Compra> lista = new ArrayList<>();
        String sql = "SELECT c.idCompra, c.numeroFactura, c.fecha, p.nombre AS proveedor, "
                + "u.nombreUsuario AS usuario, c.total "
                + "FROM Compra c "
                + "INNER JOIN Proveedor p ON c.idProveedor = p.idProveedor "
                + "INNER JOIN Usuario u ON c.idUsuario = u.idUsuario "
                + "ORDER BY c.idCompra DESC";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Compra c = new Compra();
                c.setIdCompra(rs.getInt("idCompra"));
                c.setNumeroFactura(rs.getString("numeroFactura"));
                c.setFecha(rs.getString("fecha"));
                c.setNombreProveedor(rs.getString("proveedor"));
                c.setNombreUsuario(rs.getString("usuario"));
                c.setTotal(rs.getDouble("total"));
                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error listar compras: " + e.getMessage());
        }
        return lista;
    }

    // ANULAR COMPRA
    public boolean anularCompra(int idCompra, Usuario usuario) {
        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            cs = con.prepareCall("{CALL sp_anular_compra(?)}");
            cs.setInt(1, idCompra);
            cs.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error anular compra: " + e.getMessage());
            return false;
        }
    }

    // GENERAR NÚMERO FACTURA
    public String generarNumeroFactura(Usuario usuario) {
        String numero = "";
        String sql = "SELECT fn_generar_numero_factura() AS numero";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                numero = rs.getString("numero");
            }

        } catch (Exception e) {
            System.out.println("Error generar número de factura: " + e.getMessage());
        }
        return numero;
    }

    // BUSCAR COMPRAS
    public List<Compra> buscarCompras(String texto, Usuario usuario) {
        List<Compra> lista = new ArrayList<>();

        String sql = "SELECT c.idCompra, c.numeroFactura, c.fecha, p.nombre AS proveedor, "
                + "u.nombreUsuario AS usuario, c.total "
                + "FROM Compra c "
                + "INNER JOIN Proveedor p ON c.idProveedor = p.idProveedor "
                + "INNER JOIN Usuario u ON c.idUsuario = u.idUsuario "
                + "WHERE c.numeroFactura LIKE ? "
                + "OR p.nombre LIKE ? "
                + "OR u.nombreUsuario LIKE ? "
                + "OR c.fecha LIKE ? "
                + "ORDER BY c.idCompra DESC";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);

            for (int i = 1; i <= 4; i++) {
                ps.setString(i, "%" + texto + "%");
            }

            rs = ps.executeQuery();

            while (rs.next()) {
                Compra c = new Compra();
                c.setIdCompra(rs.getInt("idCompra"));
                c.setNumeroFactura(rs.getString("numeroFactura"));
                c.setFecha(rs.getString("fecha"));
                c.setNombreProveedor(rs.getString("proveedor"));
                c.setNombreUsuario(rs.getString("usuario"));
                c.setTotal(rs.getDouble("total"));
                lista.add(c);
            }

        } catch (Exception e) {
            System.out.println("Error buscar compras: " + e.getMessage());
        }
        return lista;
    }

}
