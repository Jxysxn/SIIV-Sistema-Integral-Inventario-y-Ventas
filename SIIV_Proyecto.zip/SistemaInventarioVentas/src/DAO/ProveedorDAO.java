/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Proveedor;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // LISTAR GENERAL
    public List<Proveedor> listar(Usuario usr) {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT * FROM Proveedor";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proveedor p = new Proveedor();
                p.setIdProveedor(rs.getInt("idProveedor"));
                p.setNombre(rs.getString("nombre"));
                p.setTelefono(rs.getString("telefono"));
                p.setCorreo(rs.getString("correo"));
                p.setDireccion(rs.getString("direccion"));
                p.setEstado(rs.getString("estado"));
                lista.add(p);
            }

        } catch (Exception e) {
            System.out.println("Error al listar proveedores: " + e.getMessage());
        }
        return lista;
    }

    // LISTAR SOLO ACTIVOS PARA COMPRAS
    public List<Proveedor> listarActivos(Usuario usr) {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT idProveedor, nombre FROM Proveedor WHERE estado = 'Activo'";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proveedor p = new Proveedor();
                p.setIdProveedor(rs.getInt("idProveedor"));
                p.setNombre(rs.getString("nombre"));
                lista.add(p);
            }

        } catch (Exception e) {
            System.out.println("Error listar proveedores activos: " + e.getMessage());
        }
        return lista;
    }

    // INSERTAR (ADMIN)
    public boolean insertar(Proveedor p, Usuario usr) {
        String sql = "INSERT INTO Proveedor (nombre, telefono, correo, direccion, estado) VALUES (?, ?, ?, ?, ?)";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTelefono());
            ps.setString(3, p.getCorreo());
            ps.setString(4, p.getDireccion());
            ps.setString(5, p.getEstado());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al insertar proveedor: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR (ADMIN)
    public boolean actualizar(Proveedor p, Usuario usr) {
        String sql = "UPDATE Proveedor SET nombre=?, telefono=?, correo=?, direccion=?, estado=? WHERE idProveedor=?";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getTelefono());
            ps.setString(3, p.getCorreo());
            ps.setString(4, p.getDireccion());
            ps.setString(5, p.getEstado());
            ps.setInt(6, p.getIdProveedor());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al actualizar proveedor: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR (ADMIN)
    public boolean eliminar(int id, Usuario usr) {
        String sql = "DELETE FROM Proveedor WHERE idProveedor=?";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al eliminar proveedor: " + e.getMessage());
            return false;
        }
    }

    // BUSCAR
    public List<Proveedor> buscar(String texto, Usuario usr) {
        List<Proveedor> lista = new ArrayList<>();
        String sql = "SELECT * FROM Proveedor WHERE nombre LIKE ? OR telefono LIKE ? OR correo LIKE ? OR direccion LIKE ? OR estado LIKE ?";

        try {
            con = Conexion.getConexion(usr.getDbUser(), usr.getDbPass());
            ps = con.prepareStatement(sql);

            for (int i = 1; i <= 5; i++) {
                ps.setString(i, "%" + texto + "%");
            }

            rs = ps.executeQuery();
            while (rs.next()) {
                Proveedor p = new Proveedor();
                p.setIdProveedor(rs.getInt("idProveedor"));
                p.setNombre(rs.getString("nombre"));
                p.setTelefono(rs.getString("telefono"));
                p.setCorreo(rs.getString("correo"));
                p.setDireccion(rs.getString("direccion"));
                p.setEstado(rs.getString("estado"));
                lista.add(p);
            }

        } catch (Exception e) {
            System.out.println("Error buscar proveedores: " + e.getMessage());
        }
        return lista;
    }

    // OBTENER NOMBRE PROVEEDOR POR ID
    public String obtenerNombreProveedor(int id, Usuario usuario) {
        String nombre = "";
        String sql = "SELECT nombre FROM Proveedor WHERE idProveedor=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                nombre = rs.getString("nombre");
            }

        } catch (Exception e) {
            System.out.println("Error obtener nombre proveedor: " + e.getMessage());
        }
        return nombre;
    }

// OBTENER ID PROVEEDOR POR NOMBRE
    public int obtenerIdProveedor(String nombre, Usuario usuario) {
        int id = 0;
        String sql = "SELECT idProveedor FROM Proveedor WHERE nombre=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            if (rs.next()) {
                id = rs.getInt("idProveedor");
            }

        } catch (Exception e) {
            System.out.println("Error obtener ID proveedor: " + e.getMessage());
        }
        return id;
    }

}
