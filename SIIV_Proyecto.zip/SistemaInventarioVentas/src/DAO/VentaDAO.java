/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Usuario;
import Modelo.Venta;
import Util.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VentaDAO {

    Connection con;
    PreparedStatement ps;
    CallableStatement cs;
    ResultSet rs;

    // REGISTRAR VENTA (SP)
    public int registrarVenta(int idCliente, int idUsuario, Usuario usuario) {
        int idGenerado = 0;

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            cs = con.prepareCall("{CALL sp_registrar_venta(?, ?, ?)}");
            cs.setInt(1, idCliente);
            cs.setInt(2, idUsuario);
            cs.registerOutParameter(3, java.sql.Types.INTEGER);

            cs.execute();
            idGenerado = cs.getInt(3);

        } catch (Exception e) {
            System.out.println("Error registrar venta: " + e.getMessage());
        }
        return idGenerado;
    }

    // ACTUALIZAR CAMPOS DESCUENTO / IMPUESTO / TOTAL (por si quieres guardar)
    public void actualizarTotales(int idVenta, double descuento, double impuesto, double total, Usuario usuario) {
        String sql = "UPDATE Venta SET descuento=?, impuesto=?, total=? WHERE idVenta=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setDouble(1, descuento);
            ps.setDouble(2, impuesto);
            ps.setDouble(3, total);
            ps.setInt(4, idVenta);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Error actualizar totales venta: " + e.getMessage());
        }
    }

    // LISTAR VENTAS (solo las que no están anuladas => total > 0)
    public List<Venta> listarVentas(Usuario usuario) {
        List<Venta> lista = new ArrayList<>();

        String sql = "SELECT v.idVenta, v.numeroFactura, v.fecha, v.total, "
                + "c.nombre AS cliente, u.nombreUsuario AS usuario "
                + "FROM Venta v "
                + "INNER JOIN Cliente c ON v.idCliente = c.idCliente "
                + "INNER JOIN Usuario u ON v.idUsuario = u.idUsuario "
                + "WHERE v.total > 0 "
                + "ORDER BY v.idVenta DESC";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Venta v = new Venta();
                v.setIdVenta(rs.getInt("idVenta"));
                v.setNumeroFactura(rs.getString("numeroFactura"));
                v.setFecha(rs.getString("fecha"));
                v.setTotal(rs.getDouble("total"));
                v.setNombreCliente(rs.getString("cliente"));
                v.setNombreUsuario(rs.getString("usuario"));
                lista.add(v);
            }

        } catch (Exception e) {
            System.out.println("Error listar ventas: " + e.getMessage());
        }
        return lista;
    }

    // BUSCAR VENTAS (por factura, cliente, usuario o fecha)
    public List<Venta> buscarVentas(String texto, Usuario usuario) {
        List<Venta> lista = new ArrayList<>();

        String sql = "SELECT v.idVenta, v.numeroFactura, v.fecha, v.total, "
                + "c.nombre AS cliente, u.nombreUsuario AS usuario "
                + "FROM Venta v "
                + "INNER JOIN Cliente c ON v.idCliente = c.idCliente "
                + "INNER JOIN Usuario u ON v.idUsuario = u.idUsuario "
                + "WHERE v.total > 0 AND ("
                + "v.numeroFactura LIKE ? OR "
                + "c.nombre LIKE ? OR "
                + "u.nombreUsuario LIKE ? OR "
                + "DATE(v.fecha) LIKE ? ) "
                + "ORDER BY v.idVenta DESC";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);

            for (int i = 1; i <= 4; i++) {
                ps.setString(i, "%" + texto + "%");
            }

            rs = ps.executeQuery();

            while (rs.next()) {
                Venta v = new Venta();
                v.setIdVenta(rs.getInt("idVenta"));
                v.setNumeroFactura(rs.getString("numeroFactura"));
                v.setFecha(rs.getString("fecha"));
                v.setTotal(rs.getDouble("total"));
                v.setNombreCliente(rs.getString("cliente"));
                v.setNombreUsuario(rs.getString("usuario"));
                lista.add(v);
            }

        } catch (Exception e) {
            System.out.println("Error buscar ventas: " + e.getMessage());
        }
        return lista;
    }

    // ANULAR VENTA (SP)
    public boolean anularVenta(int idVenta, Usuario usuario) {
        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            cs = con.prepareCall("{CALL sp_anular_venta(?)}");
            cs.setInt(1, idVenta);
            cs.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error anular venta: " + e.getMessage());
            return false;
        }
    }

    // GENERAR NÚMERO DE VENTA
    public String generarNumeroVenta(Usuario usuario) {
        String numero = "";
        String sql = "SELECT fn_generar_numero_venta() AS numero";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                numero = rs.getString("numero");
            }

        } catch (Exception e) {
            System.out.println("Error generar número de venta: " + e.getMessage());
        }
        return numero;
    }
}
