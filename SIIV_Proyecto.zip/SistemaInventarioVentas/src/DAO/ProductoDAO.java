/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Producto;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // LISTAR PRODUCTOS
    public List<Producto> listar(Usuario usuario) {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT * FROM Producto";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Producto p = new Producto();
                p.setIdProducto(rs.getInt("idProducto"));
                p.setNombre(rs.getString("nombre"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecioCompra(rs.getDouble("precioCompra"));
                p.setPrecioVenta(rs.getDouble("precioVenta"));
                p.setStock(rs.getInt("stock"));
                p.setEstado(rs.getString("estado"));
                p.setIdCategoria(rs.getInt("idCategoria"));
                p.setIdProveedor(rs.getInt("idProveedor"));
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.println("Error al listar productos: " + e.getMessage());
        }
        return lista;
    }

    // INSERTAR PRODUCTO
    public boolean insertar(Producto p, Usuario usuario) {
        String sql = "INSERT INTO Producto (nombre, descripcion, precioCompra, precioVenta, stock, estado, idCategoria, idProveedor) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecioCompra());
            ps.setDouble(4, p.getPrecioVenta());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getEstado());
            ps.setInt(7, p.getIdCategoria());
            ps.setInt(8, p.getIdProveedor());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al insertar producto: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR PRODUCTO
    public boolean actualizar(Producto p, Usuario usuario) {
        String sql = "UPDATE Producto SET nombre=?, descripcion=?, precioCompra=?, precioVenta=?, stock=?, estado=?, idCategoria=?, idProveedor=? "
                + "WHERE idProducto=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getDescripcion());
            ps.setDouble(3, p.getPrecioCompra());
            ps.setDouble(4, p.getPrecioVenta());
            ps.setInt(5, p.getStock());
            ps.setString(6, p.getEstado());
            ps.setInt(7, p.getIdCategoria());
            ps.setInt(8, p.getIdProveedor());
            ps.setInt(9, p.getIdProducto());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR PRODUCTO
    public boolean eliminar(int id, Usuario usuario) {
        String sql = "DELETE FROM Producto WHERE idProducto=?";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    // BUSCAR PRODUCTO POR NOMBRE
    public Producto buscarPorNombre(String nombre, Usuario usuario) {
        Producto p = null;
        String sql = "SELECT * FROM Producto WHERE nombre = ? LIMIT 1";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();

            if (rs.next()) {
                p = new Producto();
                p.setIdProducto(rs.getInt("idProducto"));
                p.setNombre(rs.getString("nombre"));
                p.setDescripcion(rs.getString("descripcion"));
                p.setPrecioCompra(rs.getDouble("precioCompra"));
                p.setPrecioVenta(rs.getDouble("precioVenta"));
                p.setStock(rs.getInt("stock"));
                p.setEstado(rs.getString("estado"));
                p.setIdCategoria(rs.getInt("idCategoria"));
                p.setIdProveedor(rs.getInt("idProveedor"));
            }

        } catch (Exception e) {
            System.out.println("Error al buscar producto: " + e.getMessage());
        }
        return p;
    }

    // OBTENER ID PRODUCTO POR NOMBRE
    public int obtenerIdProductoPorNombre(String nombre, Usuario usuario) {
        int id = 0;
        String sql = "SELECT idProducto FROM Producto WHERE nombre = ? LIMIT 1";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();

            if (rs.next()) {
                id = rs.getInt("idProducto");
            }

        } catch (Exception e) {
            System.out.println("Error obtener id producto: " + e.getMessage());
        }
        return id;
    }
}
