/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.FormaPago;
import Modelo.Usuario;
import Util.Conexion;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FormaPagoDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    public List<FormaPago> listar(Usuario usuario) {
        List<FormaPago> lista = new ArrayList<>();
        String sql = "SELECT idFormaPago, nombre, descripcion FROM FormaPago";

        try {
            con = Conexion.getConexion(usuario.getDbUser(), usuario.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                FormaPago f = new FormaPago();
                f.setIdFormaPago(rs.getInt("idFormaPago"));
                f.setNombre(rs.getString("nombre"));
                f.setDescripcion(rs.getString("descripcion"));
                lista.add(f);
            }

        } catch (Exception e) {
            System.out.println("Error listar formas de pago: " + e.getMessage());
        }
        return lista;
    }
}
