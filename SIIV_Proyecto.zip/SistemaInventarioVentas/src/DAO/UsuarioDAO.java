/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Modelo.Usuario;
import Util.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    Connection con;
    PreparedStatement ps;
    ResultSet rs;

    // LISTAR USUARIOS
    public List<Usuario> listar(Usuario usuarioLogueado) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.idUsuario, u.nombreUsuario, u.contrasena, u.estado, r.idRol, r.nombre AS rol "
                + "FROM Usuario u INNER JOIN Rol r ON u.idRol = r.idRol";

        try {
            con = Conexion.getConexion(usuarioLogueado.getDbUser(), usuarioLogueado.getDbPass());
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Usuario u = new Usuario();
                u.setIdUsuario(rs.getInt("idUsuario"));
                u.setNombreUsuario(rs.getString("nombreUsuario"));
                u.setEstado(rs.getString("estado"));
                u.setIdRol(rs.getInt("idRol"));
                u.setNombreRol(rs.getString("rol"));
                lista.add(u);
            }

        } catch (Exception e) {
            System.out.println("Error al listar usuarios: " + e.getMessage());
        }
        return lista;
    }

    // INSERTAR USUARIO
    public boolean insertar(Usuario u, Usuario usuarioLogueado) {
        String sql = "INSERT INTO Usuario (nombreUsuario, contrasena, estado, idRol) VALUES (?, ?, ?, ?)";

        try {
            con = Conexion.getConexion(usuarioLogueado.getDbUser(), usuarioLogueado.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getContrasena());
            ps.setString(3, u.getEstado());
            ps.setInt(4, u.getIdRol());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al insertar usuario: " + e.getMessage());
            return false;
        }
    }

    // ACTUALIZAR USUARIO
    public boolean actualizar(Usuario u, Usuario usuarioLogueado) {
        String sql = "UPDATE Usuario SET nombreUsuario=?, contrasena=?, estado=?, idRol=? WHERE idUsuario=?";

        try {
            con = Conexion.getConexion(usuarioLogueado.getDbUser(), usuarioLogueado.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setString(1, u.getNombreUsuario());
            ps.setString(2, u.getContrasena());
            ps.setString(3, u.getEstado());
            ps.setInt(4, u.getIdRol());
            ps.setInt(5, u.getIdUsuario());
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    // ELIMINAR USUARIO
    public boolean eliminar(int id, Usuario usuarioLogueado) {
        String sql = "DELETE FROM Usuario WHERE idUsuario=?";

        try {
            con = Conexion.getConexion(usuarioLogueado.getDbUser(), usuarioLogueado.getDbPass());
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al eliminar usuario: " + e.getMessage());
            return false;
        }
    }

    // LOGIN
    public Usuario login(String usuario, String clave) {
        Usuario u = null;

        String sql = "SELECT u.idUsuario, u.nombreUsuario, u.contrasena, u.estado, "
                + "r.idRol, r.nombre AS rol, r.dbUser, r.dbPass "
                + "FROM Usuario u "
                + "INNER JOIN Rol r ON u.idRol = r.idRol "
                + "WHERE u.nombreUsuario=? AND u.contrasena=? AND u.estado='Activo' LIMIT 1";

        try {
            con = Conexion.getConexion("admin_db", "Admin123*"); // Conexión base para validar login
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, clave);
            rs = ps.executeQuery();

            if (rs.next()) {
                u = new Usuario();
                u.setIdUsuario(rs.getInt("idUsuario"));
                u.setNombreUsuario(rs.getString("nombreUsuario"));
                u.setContrasena(rs.getString("contrasena"));
                u.setEstado(rs.getString("estado"));
                u.setIdRol(rs.getInt("idRol"));
                u.setNombreRol(rs.getString("rol"));
                u.setDbUser(rs.getString("dbUser"));
                u.setDbPass(rs.getString("dbPass"));
            }

        } catch (Exception e) {
            System.out.println("Error en login: " + e.getMessage());
        }
        return u;
    }

}
