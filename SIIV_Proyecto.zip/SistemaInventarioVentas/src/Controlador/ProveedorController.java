/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.ProveedorDAO;
import Modelo.Proveedor;
import Modelo.Usuario;
import Vista.FrmProveedor;
import Vista.FrmPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ProveedorController implements ActionListener {

    FrmProveedor vista;
    FrmPrincipal principal;
    Usuario usuarioLogueado;

    ProveedorDAO proveedorDAO = new ProveedorDAO();
    Proveedor proveedor = new Proveedor();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public ProveedorController(FrmProveedor v, FrmPrincipal p, Usuario usuarioLogueado) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuarioLogueado;

        vista.btnGuardar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnVolver.addActionListener(this);

        vista.tableProveedor.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarSeleccion();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        vista.cbEstado.removeAllItems();
        vista.cbEstado.addItem("Activo");
        vista.cbEstado.addItem("Inactivo");
        vista.txtIdProveedor.setEditable(false);

        aplicarPermisosPorRol();
        listar();
    }

    // PERMISOS POR ROL
    private void aplicarPermisosPorRol() {
        if (usuarioLogueado == null) return;

        int rol = usuarioLogueado.getIdRol(); // 1 = Admin

        if (rol != 1) { 
            vista.btnGuardar.setEnabled(false);
            vista.btnActualizar.setEnabled(false);
            vista.btnEliminar.setEnabled(false);
        }
    }

    // LISTAR
    private void listar() {
        modeloTabla = (DefaultTableModel) vista.tableProveedor.getModel();
        modeloTabla.setRowCount(0);

        for (Proveedor p : proveedorDAO.listar(usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                p.getIdProveedor(),
                p.getNombre(),
                p.getTelefono(),
                p.getCorreo(),
                p.getDireccion(),
                p.getEstado()
            });
        }
    }

    // BÚSQUEDA AVANZADA
    private void buscar() {
        String criterio = vista.txtBuscar.getText().trim().toLowerCase();

        if (criterio.isEmpty()) {
            listar();
            return;
        }

        modeloTabla.setRowCount(0);

        for (Proveedor p : proveedorDAO.buscar(criterio, usuarioLogueado)) {
            boolean coincide =
                p.getNombre().toLowerCase().contains(criterio) ||
                p.getTelefono().toLowerCase().contains(criterio) ||
                p.getCorreo().toLowerCase().contains(criterio) ||
                p.getDireccion().toLowerCase().contains(criterio) ||
                p.getEstado().toLowerCase().contains(criterio);

            if (coincide) {
                modeloTabla.addRow(new Object[]{
                    p.getIdProveedor(),
                    p.getNombre(),
                    p.getTelefono(),
                    p.getCorreo(),
                    p.getDireccion(),
                    p.getEstado()
                });
            }
        }
    }

    // CARGAR SELECCIÓN
    private void cargarSeleccion() {
        int fila = vista.tableProveedor.getSelectedRow();
        if (fila < 0) return;

        vista.txtIdProveedor.setText(vista.tableProveedor.getValueAt(fila, 0).toString());
        vista.txtNombre.setText(vista.tableProveedor.getValueAt(fila, 1).toString());
        vista.txtTelefono.setText(vista.tableProveedor.getValueAt(fila, 2).toString());
        vista.txtCorreo.setText(vista.tableProveedor.getValueAt(fila, 3).toString());
        vista.txtDireccion.setText(vista.tableProveedor.getValueAt(fila, 4).toString());
        vista.cbEstado.setSelectedItem(vista.tableProveedor.getValueAt(fila, 5).toString());
    }

    // VALIDAR CAMPOS
    private boolean validar() {
        if (
            vista.txtNombre.getText().trim().isEmpty() ||
            vista.txtTelefono.getText().trim().isEmpty() ||
            vista.txtCorreo.getText().trim().isEmpty() ||
            vista.txtDireccion.getText().trim().isEmpty()
        ) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return false;
        }
        return true;
    }

    // GUARDAR
    private void guardar() {
        if (!vista.btnGuardar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para agregar proveedores.");
            return;
        }

        if (!validar()) return;

        proveedor.setNombre(vista.txtNombre.getText());
        proveedor.setTelefono(vista.txtTelefono.getText());
        proveedor.setCorreo(vista.txtCorreo.getText());
        proveedor.setDireccion(vista.txtDireccion.getText());
        proveedor.setEstado(vista.cbEstado.getSelectedItem().toString());

        proveedorDAO.insertar(proveedor, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Proveedor creado correctamente.");
    }

    // ACTUALIZAR
    private void actualizar() {
        if (!vista.btnActualizar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para actualizar.");
            return;
        }

        if (vista.txtIdProveedor.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un proveedor primero.");
            return;
        }

        proveedor.setIdProveedor(Integer.parseInt(vista.txtIdProveedor.getText()));
        proveedor.setNombre(vista.txtNombre.getText());
        proveedor.setTelefono(vista.txtTelefono.getText());
        proveedor.setCorreo(vista.txtCorreo.getText());
        proveedor.setDireccion(vista.txtDireccion.getText());
        proveedor.setEstado(vista.cbEstado.getSelectedItem().toString());

        proveedorDAO.actualizar(proveedor, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Proveedor actualizado correctamente.");
    }

    // ELIMINAR
    private void eliminar() {
        if (!vista.btnEliminar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para eliminar.");
            return;
        }

        if (vista.txtIdProveedor.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un proveedor primero.");
            return;
        }

        int opc = JOptionPane.showConfirmDialog(null,
                "¿Eliminar proveedor seleccionado?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION);

        if (opc == JOptionPane.YES_OPTION) {
            proveedorDAO.eliminar(Integer.parseInt(vista.txtIdProveedor.getText()), usuarioLogueado);
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Proveedor eliminado correctamente.");
        }
    }

    // LIMPIAR
    private void limpiar() {
        vista.txtIdProveedor.setText("");
        vista.txtNombre.setText("");
        vista.txtTelefono.setText("");
        vista.txtCorreo.setText("");
        vista.txtDireccion.setText("");
        vista.txtBuscar.setText("");
        vista.cbEstado.setSelectedIndex(0);
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) guardar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnLimpiar) limpiar();

        if (e.getSource() == vista.btnVolver) {
            vista.dispose();
            principal.setVisible(true);
        }
    }
}
