/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.ClienteDAO;
import DAO.CompraDAO;
import DAO.DetalleVentaDAO;
import DAO.FormaPagoDAO;
import DAO.ProductoDAO;
import DAO.VentaDAO;
import Modelo.Cliente;
import Modelo.DetalleVenta;
import Modelo.FormaPago;
import Modelo.Usuario;
import Vista.DlgAgregarProductoVenta;
import Vista.FrmPrincipal;
import Vista.FrmVenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentaController implements ActionListener {

    private FrmVenta vista;
    private FrmPrincipal principal;
    private Usuario usuarioLogueado;

    private DefaultTableModel modeloTabla = new DefaultTableModel();

    private VentaDAO ventaDAO = new VentaDAO();
    private DetalleVentaDAO detalleDAO = new DetalleVentaDAO();
    private ProductoDAO productoDAO = new ProductoDAO();
    private ClienteDAO clienteDAO = new ClienteDAO();
    private FormaPagoDAO formaPagoDAO = new FormaPagoDAO();

    private static final double IVA_PORCENTAJE = 0.19;

    public VentaController(FrmVenta v, FrmPrincipal p, Usuario usuario) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuario;

        vista.lblUsuarioActivo.setText(usuario.getNombreUsuario());

        vista.btnVolver.addActionListener(this);
        vista.btnAgregarProducto.addActionListener(this);
        vista.btnEliminarDetalle.addActionListener(this);
        vista.btnConsultarVentas.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);

        // cuando cambie el descuento, recalculamos totales
        vista.txtDescuento.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                recalcularTotales();
            }
        });

        vista.txtImpuesto.setEditable(false);

        configurarTabla();
        cargarClientes();
        cargarFormasPago();
        inicializarCabecera();
    }

    // TABLA DETALLE
    private void configurarTabla() {
        modeloTabla = (DefaultTableModel) vista.tableDetalleVenta.getModel();
        modeloTabla.setRowCount(0);
        vista.tableDetalleVenta.setModel(modeloTabla);
    }

    // CLIENTES ACTIVOS
    private void cargarClientes() {
        vista.cbCliente.removeAllItems();
        for (Cliente c : clienteDAO.listar(usuarioLogueado)) {
            if ("Activo".equalsIgnoreCase(c.getEstado())) {
                vista.cbCliente.addItem(c.getIdCliente() + " - " + c.getNombre());
            }
        }
    }

    // FORMAS DE PAGO
    private void cargarFormasPago() {
        vista.cbFormaPago.removeAllItems();
        for (FormaPago f : formaPagoDAO.listar(usuarioLogueado)) {
            vista.cbFormaPago.addItem(f.getIdFormaPago() + " - " + f.getNombre());
        }
    }

    // CABECERA (FECHA + NUM. FACTURA)
    private void inicializarCabecera() {
        vista.txtFecha.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        vista.txtFecha.setEnabled(false);

        String numero = ventaDAO.generarNumeroVenta(usuarioLogueado);
        if (numero == null || numero.trim().isEmpty()) {
            numero = "V-00001";
        }

        vista.txtNumFactura.setText(numero);
        vista.txtNumFactura.setEnabled(false);

        // limpiar totales
        vista.txtDescuento.setText("");
        vista.txtImpuesto.setText("");
        vista.txtTotal.setText("");
    }

    // RECALCULAR TOTAL, DESCUENTO E IVA
    public void recalcularTotales() {
        double base = 0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            base += Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());
        }

        // porcentaje de descuento
        double porcDesc = 0;
        String txtDesc = vista.txtDescuento.getText().trim();
        if (!txtDesc.isEmpty()) {
            try {
                porcDesc = Double.parseDouble(txtDesc);
                if (porcDesc < 0 || porcDesc > 100) {
                    JOptionPane.showMessageDialog(null, "El descuento debe estar entre 0 y 100");
                    porcDesc = 0;
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Descuento inválido, se tomará como 0%");
                porcDesc = 0;
            }
        }

        double valorDesc = base * (porcDesc / 100.0);
        double baseConDescuento = base - valorDesc;

        double impuesto = baseConDescuento * IVA_PORCENTAJE;
        double totalFinal = baseConDescuento + impuesto;

        vista.txtImpuesto.setText(String.format("%.2f", impuesto));
        vista.txtTotal.setText(String.format("%.2f", totalFinal));
    }

    // LIMPIAR FORM
    private void limpiar() {
        modeloTabla.setRowCount(0);
        vista.txtDescuento.setText("");
        vista.txtImpuesto.setText("");
        vista.txtTotal.setText("");
        if (vista.cbCliente.getItemCount() > 0) {
            vista.cbCliente.setSelectedIndex(0);
        }
        if (vista.cbFormaPago.getItemCount() > 0) {
            vista.cbFormaPago.setSelectedIndex(0);
        }
        inicializarCabecera();
    }

    // GUARDAR VENTA COMPLETA
    private void guardarVenta() {

        if (modeloTabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Debe agregar productos antes de guardar.");
            return;
        }

        if (vista.cbCliente.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un cliente.");
            return;
        }

        if (vista.cbFormaPago.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar una forma de pago.");
            return;
        }

        // ID cliente
        String itemCliente = vista.cbCliente.getSelectedItem().toString();
        int idCliente = Integer.parseInt(itemCliente.split(" - ")[0]);

        // ID forma pago
        String itemFP = vista.cbFormaPago.getSelectedItem().toString();
        int idFormaPago = Integer.parseInt(itemFP.split(" - ")[0]);

        // registrar venta (SP)
        int idVenta = ventaDAO.registrarVenta(idCliente, usuarioLogueado.getIdUsuario(), usuarioLogueado);

        if (idVenta <= 0) {
            JOptionPane.showMessageDialog(null, "Error al registrar la venta.");
            return;
        }

        // registrar detalles
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            DetalleVenta d = new DetalleVenta();
            d.setIdVenta(idVenta);
            d.setIdProducto(productoDAO.obtenerIdProductoPorNombre(
                    modeloTabla.getValueAt(i, 0).toString(), usuarioLogueado));
            d.setCantidad(Integer.parseInt(modeloTabla.getValueAt(i, 1).toString()));
            d.setPrecioUnitario(Double.parseDouble(modeloTabla.getValueAt(i, 2).toString()));
            detalleDAO.registrarDetalle(d, usuarioLogueado);
        }

        // recalc totales para guardar descuento / impuesto / total
        double base = 0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            base += Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());
        }

        double porcDesc = 0;
        String txtDesc = vista.txtDescuento.getText().trim();
        if (!txtDesc.isEmpty()) {
            try {
                porcDesc = Double.parseDouble(txtDesc);
                if (porcDesc < 0 || porcDesc > 100) {
                    porcDesc = 0;
                }
            } catch (NumberFormatException e) {
                porcDesc = 0;
            }
        }

        double valorDesc = base * (porcDesc / 100.0);
        double baseConDescuento = base - valorDesc;
        double impuesto = baseConDescuento * IVA_PORCENTAJE;
        double totalFinal = baseConDescuento + impuesto;

        ventaDAO.actualizarTotales(idVenta, valorDesc, impuesto, totalFinal, usuarioLogueado);

        JOptionPane.showMessageDialog(null, "Venta registrada con éxito.");
        limpiar();
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnVolver) {
            principal.setVisible(true);
            vista.dispose();
        }

        if (e.getSource() == vista.btnAgregarProducto) {
            DlgAgregarProductoVenta dlg = new DlgAgregarProductoVenta(vista, true);
            new AgregarProductoVentaController(dlg, vista, modeloTabla, usuarioLogueado, this);
            dlg.setVisible(true);
        }

        if (e.getSource() == vista.btnEliminarDetalle) {
            int fila = vista.tableDetalleVenta.getSelectedRow();
            if (fila >= 0) {
                modeloTabla.removeRow(fila);
                recalcularTotales();
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un item primero.");
            }
        }

        if (e.getSource() == vista.btnConsultarVentas) {
            Vista.FrmVentaConsulta frm = new Vista.FrmVentaConsulta();
            new VentaConsultaController(frm, vista, usuarioLogueado);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnGuardar) {
            guardarVenta();
        }

        if (e.getSource() == vista.btnLimpiar) {
            limpiar();
        }
    }
}
