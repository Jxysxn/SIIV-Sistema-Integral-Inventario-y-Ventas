/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.DetalleVentaDAO;
import DAO.VentaDAO;
import Modelo.DetalleVenta;
import Modelo.Usuario;
import Modelo.Venta;
import Vista.FrmVenta;
import Vista.FrmVentaConsulta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VentaConsultaController implements ActionListener {

    private FrmVentaConsulta vista;
    private FrmVenta vistaRegreso;
    private Usuario usuarioLogueado;

    private DefaultTableModel modeloVentas = new DefaultTableModel();
    private DefaultTableModel modeloDetalle = new DefaultTableModel();

    private VentaDAO ventaDAO = new VentaDAO();
    private DetalleVentaDAO detalleDAO = new DetalleVentaDAO();

    public VentaConsultaController(FrmVentaConsulta v, FrmVenta regresar, Usuario usuario) {
        this.vista = v;
        this.vistaRegreso = regresar;
        this.usuarioLogueado = usuario;

        vista.btnAnular.addActionListener(this);
        vista.btnRegresar.addActionListener(this);

        vista.tableVentas.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarDetalle();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        configurarTablas();
        listarVentas();
    }

    private void configurarTablas() {
        modeloVentas = (DefaultTableModel) vista.tableVentas.getModel();
        modeloVentas.setRowCount(0);

        modeloDetalle = (DefaultTableModel) vista.tableDetalle.getModel();
        modeloDetalle.setRowCount(0);
    }

    private void listarVentas() {
        modeloVentas.setRowCount(0);

        for (Venta v : ventaDAO.listarVentas(usuarioLogueado)) {
            modeloVentas.addRow(new Object[]{
                v.getIdVenta(),
                v.getNumeroFactura(),
                v.getFecha(),
                v.getNombreCliente(),
                v.getNombreUsuario(),
                v.getTotal()
            });
        }
        modeloDetalle.setRowCount(0);
    }

    private void cargarDetalle() {
        int fila = vista.tableVentas.getSelectedRow();
        if (fila < 0) {
            return;
        }

        int idVenta = Integer.parseInt(vista.tableVentas.getValueAt(fila, 0).toString());

        modeloDetalle.setRowCount(0);

        for (DetalleVenta d : detalleDAO.listarPorVenta(idVenta, usuarioLogueado)) {
            modeloDetalle.addRow(new Object[]{
                d.getNombreProducto(),
                d.getCantidad(),
                d.getPrecioUnitario(),
                d.getSubtotal()
            });
        }
    }

    private void buscar() {
        String texto = vista.txtBuscar.getText().trim();
        modeloVentas.setRowCount(0);

        for (Venta v : ventaDAO.buscarVentas(texto, usuarioLogueado)) {
            modeloVentas.addRow(new Object[]{
                v.getIdVenta(),
                v.getNumeroFactura(),
                v.getFecha(),
                v.getNombreCliente(),
                v.getNombreUsuario(),
                v.getTotal()
            });
        }
        modeloDetalle.setRowCount(0);
    }

    private void anularVenta() {
        int fila = vista.tableVentas.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(null, "Seleccione una venta primero.");
            return;
        }

        double total = Double.parseDouble(vista.tableVentas.getValueAt(fila, 5).toString());
        if (total == 0) {
            JOptionPane.showMessageDialog(null, "Esta venta ya fue anulada previamente.");
            return;
        }

        int idVenta = Integer.parseInt(vista.tableVentas.getValueAt(fila, 0).toString());

        if (JOptionPane.showConfirmDialog(null,
                "¿Desea anular la venta seleccionada?",
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            ventaDAO.anularVenta(idVenta, usuarioLogueado);
            listarVentas();
            JOptionPane.showMessageDialog(null, "Venta anulada correctamente");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnAnular) {
            anularVenta();
        }

        if (e.getSource() == vista.btnRegresar) {
            vista.dispose();
            vistaRegreso.setVisible(true);
        }
    }
}
