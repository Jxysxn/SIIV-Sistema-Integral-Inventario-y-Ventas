/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.FrmCompraConsulta;
import Vista.FrmCompra;

import DAO.CompraDAO;
import DAO.DetalleCompraDAO;

import Modelo.Compra;
import Modelo.DetalleCompra;
import Modelo.Usuario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CompraConsultaController implements ActionListener {

    private FrmCompraConsulta vista;
    private FrmCompra vistaRegreso;
    private Usuario usuarioLogueado;

    private DefaultTableModel modeloCompras = new DefaultTableModel();
    private DefaultTableModel modeloDetalle = new DefaultTableModel();

    private CompraDAO compraDAO = new CompraDAO();
    private DetalleCompraDAO detalleDAO = new DetalleCompraDAO();

    public CompraConsultaController(FrmCompraConsulta v, FrmCompra regresar, Usuario usuario) {
        this.vista = v;
        this.vistaRegreso = regresar;
        this.usuarioLogueado = usuario;

        vista.btnAnular.addActionListener(this);
        vista.btnRegresar.addActionListener(this);

        vista.tableCompras.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarDetalle();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        configurarTablas();
        listarCompras();
    }

    // CONFIGURAR TABLAS
    private void configurarTablas() {
        modeloCompras = (DefaultTableModel) vista.tableCompras.getModel();
        modeloCompras.setRowCount(0);

        modeloDetalle = (DefaultTableModel) vista.tableDetalle.getModel();
        modeloDetalle.setRowCount(0);
    }

    // LISTAR COMPRAS
    private void listarCompras() {
        modeloCompras.setRowCount(0);

        for (Compra c : compraDAO.listarCompras(usuarioLogueado)) {
            modeloCompras.addRow(new Object[]{
                c.getIdCompra(),
                c.getNumeroFactura(),
                c.getFecha(),
                c.getNombreProveedor(),
                c.getNombreUsuario(),
                c.getTotal()
            });
        }
        modeloDetalle.setRowCount(0);
    }

    // CARGAR DETALLE
    private void cargarDetalle() {
        int fila = vista.tableCompras.getSelectedRow();
        if (fila < 0) return;

        int idCompra = Integer.parseInt(vista.tableCompras.getValueAt(fila, 0).toString());

        modeloDetalle.setRowCount(0);

        for (DetalleCompra d : detalleDAO.listarPorCompra(idCompra, usuarioLogueado)) {
            modeloDetalle.addRow(new Object[]{
                d.getNombreProducto(),
                d.getCantidad(),
                d.getPrecioUnitario(),
                d.getSubtotal()
            });
        }
    }

    // BUSCAR COMPRAS
    private void buscar() {
        String texto = vista.txtBuscar.getText().trim();
        modeloCompras.setRowCount(0);

        for (Compra c : compraDAO.buscarCompras(texto, usuarioLogueado)) {
            modeloCompras.addRow(new Object[]{
                c.getIdCompra(),
                c.getNumeroFactura(),
                c.getFecha(),
                c.getNombreProveedor(),
                c.getNombreUsuario(),
                c.getTotal()
            });
        }
        modeloDetalle.setRowCount(0);
    }

    // ANULAR COMPRA
    private void anularCompra() {

        int fila = vista.tableCompras.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(null, "Seleccione una compra primero.");
            return;
        }

        double total = Double.parseDouble(vista.tableCompras.getValueAt(fila, 5).toString());
        if (total == 0) {
            JOptionPane.showMessageDialog(null, "Esta compra ya fue anulada previamente");
            return;
        }

        int idCompra = Integer.parseInt(vista.tableCompras.getValueAt(fila, 0).toString());

        if (JOptionPane.showConfirmDialog(null, 
                "¿Desea anular la compra seleccionada?", 
                "Confirmación", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            compraDAO.anularCompra(idCompra, usuarioLogueado);
            listarCompras();
            JOptionPane.showMessageDialog(null, "Compra anulada correctamente");
        }
    }

    // EVENTOS BOTONES
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnAnular) anularCompra();

        if (e.getSource() == vista.btnRegresar) {
            vista.dispose();
            vistaRegreso.setVisible(true);
        }
    }
}
