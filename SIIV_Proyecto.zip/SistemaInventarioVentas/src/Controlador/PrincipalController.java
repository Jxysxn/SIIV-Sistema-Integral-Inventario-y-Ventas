/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelo.Usuario;
import Vista.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrincipalController implements ActionListener {

    FrmPrincipal vista;
    private Usuario usuarioLogueado;

    public PrincipalController(FrmPrincipal v, Usuario usuario) {
        this.vista = v;
        this.usuarioLogueado = usuario;

        vista.btnProductos.addActionListener(this);
        vista.btnClientes.addActionListener(this);
        vista.btnProveedores.addActionListener(this);
        vista.btnCategorias.addActionListener(this);
        vista.btnUsuarios.addActionListener(this);
        vista.btnCompras.addActionListener(this);
        vista.btnVentas.addActionListener(this);
        vista.btnCerrarSesion.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnProductos) {
            FrmProducto frm = new FrmProducto();
            new ProductoController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnClientes) {
            FrmCliente frm = new FrmCliente();
            new ClienteController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnProveedores) {
            FrmProveedor frm = new FrmProveedor();
            new ProveedorController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnCategorias) {
            FrmCategoria frm = new FrmCategoria();
            new CategoriaController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnUsuarios) {
            FrmUsuario frm = new FrmUsuario();
            new UsuarioController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnCompras) {
            FrmCompra frm = new FrmCompra();
            new CompraController(frm, vista, usuarioLogueado);
            frm.setLocationRelativeTo(null);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnVentas) {
            FrmVenta frm = new FrmVenta();
            new VentaController(frm, vista, usuarioLogueado);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnCerrarSesion) {
            FrmLogin login = new FrmLogin();
            LoginController loginController = new LoginController(login);
            loginController.iniciar();
            vista.dispose();
        }
    }
}
