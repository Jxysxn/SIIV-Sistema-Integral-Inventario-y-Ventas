/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.UsuarioDAO;
import DAO.RolDAO;
import Modelo.Usuario;
import Modelo.Rol;
import Vista.FrmUsuario;
import Vista.FrmPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class UsuarioController implements ActionListener {

    FrmUsuario vista;
    FrmPrincipal principal;
    Usuario usuarioLogueado;

    UsuarioDAO usuarioDAO = new UsuarioDAO();
    RolDAO rolDAO = new RolDAO();

    Usuario usuario = new Usuario();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public UsuarioController(FrmUsuario v, FrmPrincipal p, Usuario usuarioLogueado) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuarioLogueado;

        vista.btnGuardar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnVolver.addActionListener(this);

        vista.tableUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarSeleccion();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        vista.cbEstado.addItem("Activo");
        vista.cbEstado.addItem("Inactivo");
        vista.txtIdUsuario.setEditable(false);

        aplicarPermisosPorRol();
        cargarRoles();
        listar();
    }

    // PERMISOS POR ROL
    private void aplicarPermisosPorRol() {
        if (usuarioLogueado == null) return;

        int rol = usuarioLogueado.getIdRol();  // 1=Admin, 2=Vendedor, 3=Analista

        if (rol != 1) {  // Solo Admin puede administrar usuarios
            vista.btnGuardar.setEnabled(false);
            vista.btnActualizar.setEnabled(false);
            vista.btnEliminar.setEnabled(false);
        }
    }

    // CARGAR COMBO ROLES
    private void cargarRoles() {
        vista.cbRol.removeAllItems();
        rolDAO.listar(usuarioLogueado).forEach(r -> {
            vista.cbRol.addItem(r.getIdRol() + " - " + r.getNombre());
        });
    }

    // LISTAR TABLA
    private void listar() {
        modeloTabla = (DefaultTableModel) vista.tableUsuario.getModel();
        modeloTabla.setRowCount(0);

        for (Usuario u : usuarioDAO.listar(usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                u.getIdUsuario(),
                u.getNombreUsuario(),
                u.getEstado(),
                u.getNombreRol()
            });
        }
    }

    // BÚSQUEDA AVANZADA
    private void buscar() {
        String criterio = vista.txtBuscar.getText().trim().toLowerCase();

        if (criterio.isEmpty()) {
            listar();
            return;
        }

        modeloTabla.setRowCount(0);

        for (Usuario u : usuarioDAO.listar(usuarioLogueado)) {

            boolean coincide =
                u.getNombreUsuario().toLowerCase().contains(criterio) ||
                u.getEstado().toLowerCase().contains(criterio) ||
                (u.getNombreRol() != null && u.getNombreRol().toLowerCase().contains(criterio));

            if (coincide) {
                modeloTabla.addRow(new Object[]{
                    u.getIdUsuario(),
                    u.getNombreUsuario(),
                    u.getEstado(),
                    u.getNombreRol()
                });
            }
        }
    }

    // CARGAR SELECCIÓN
    private void cargarSeleccion() {
        int fila = vista.tableUsuario.getSelectedRow();
        if (fila < 0) return;

        vista.txtIdUsuario.setText(vista.tableUsuario.getValueAt(fila, 0).toString());
        vista.txtNombreUsuario.setText(vista.tableUsuario.getValueAt(fila, 1).toString());
        vista.cbEstado.setSelectedItem(vista.tableUsuario.getValueAt(fila, 2).toString());
        vista.cbRol.setSelectedItem(vista.tableUsuario.getValueAt(fila, 3).toString());
    }

    // VALIDAR
    private boolean validarCampos() {
        if (vista.txtNombreUsuario.getText().trim().isEmpty() ||
            String.valueOf(vista.txtContrasena.getPassword()).trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return false;
        }
        return true;
    }

    // GUARDAR
    private void guardar() {
        if (!vista.btnGuardar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para crear usuarios.");
            return;
        }

        if (!validarCampos()) return;

        usuario.setNombreUsuario(vista.txtNombreUsuario.getText().trim());
        usuario.setContrasena(String.valueOf(vista.txtContrasena.getPassword()).trim());
        usuario.setEstado(vista.cbEstado.getSelectedItem().toString());

        String[] parts = vista.cbRol.getSelectedItem().toString().split(" - ");
        usuario.setIdRol(Integer.parseInt(parts[0]));

        boolean ok = usuarioDAO.insertar(usuario, usuarioLogueado);

        if (ok) {
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Usuario creado correctamente.");
        }
    }

    // ACTUALIZAR
    private void actualizar() {
        if (!vista.btnActualizar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para actualizar usuarios.");
            return;
        }

        if (vista.txtIdUsuario.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un usuario primero");
            return;
        }

        usuario.setIdUsuario(Integer.parseInt(vista.txtIdUsuario.getText().trim()));
        usuario.setNombreUsuario(vista.txtNombreUsuario.getText().trim());
        usuario.setContrasena(String.valueOf(vista.txtContrasena.getPassword()).trim());
        usuario.setEstado(vista.cbEstado.getSelectedItem().toString());

        String[] parts = vista.cbRol.getSelectedItem().toString().split(" - ");
        usuario.setIdRol(Integer.parseInt(parts[0]));

        boolean ok = usuarioDAO.actualizar(usuario, usuarioLogueado);

        if (ok) {
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Usuario actualizado correctamente.");
        }
    }

    // ELIMINAR
    private void eliminar() {
        if (!vista.btnEliminar.isEnabled()) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para eliminar usuarios.");
            return;
        }

        if (vista.txtIdUsuario.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un usuario primero");
            return;
        }

        int opc = JOptionPane.showConfirmDialog(null,
                "¿Eliminar el usuario seleccionado?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION);

        if (opc == JOptionPane.YES_OPTION) {
            usuarioDAO.eliminar(Integer.parseInt(vista.txtIdUsuario.getText().trim()), usuarioLogueado);
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Usuario eliminado");
        }
    }

    // LIMPIAR
    private void limpiar() {
        vista.txtIdUsuario.setText("");
        vista.txtNombreUsuario.setText("");
        vista.txtContrasena.setText("");
        vista.txtBuscar.setText("");
        vista.cbEstado.setSelectedIndex(0);
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) guardar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnLimpiar) limpiar();

        if (e.getSource() == vista.btnVolver) {
            vista.dispose();
            principal.setVisible(true);
        }
    }
}
