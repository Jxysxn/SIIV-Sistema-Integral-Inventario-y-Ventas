/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.ClienteDAO;
import Modelo.Cliente;
import Modelo.Usuario;
import Vista.FrmCliente;
import Vista.FrmPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ClienteController implements ActionListener {

    FrmCliente vista;
    FrmPrincipal principal;
    Usuario usuarioLogueado;

    ClienteDAO dao = new ClienteDAO();
    Cliente cliente = new Cliente();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public ClienteController(FrmCliente v, FrmPrincipal p, Usuario usuario) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuario;

        vista.btnGuardar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnVolver.addActionListener(this);

        vista.tableCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarSeleccion();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        vista.cbEstado.removeAllItems();
        vista.cbEstado.addItem("Activo");
        vista.cbEstado.addItem("Inactivo");

        vista.txtIdCliente.setEditable(false);

        listar();
    }

    // LISTAR
    public void listar() {
        modeloTabla = (DefaultTableModel) vista.tableCliente.getModel();
        modeloTabla.setRowCount(0);

        for (Cliente c : dao.listar(usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                    c.getIdCliente(),
                    c.getNombre(),
                    c.getDocumento(),
                    c.getTelefono(),
                    c.getCorreo(),
                    c.getDireccion(),
                    c.getEstado()
            });
        }
    }

    // BUSCAR
    public void buscar() {
        String criterio = vista.txtBuscar.getText().trim();
        if (criterio.isEmpty()) {
            listar();
            return;
        }

        modeloTabla.setRowCount(0);

        for (Cliente c : dao.buscar(criterio, usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                    c.getIdCliente(),
                    c.getNombre(),
                    c.getDocumento(),
                    c.getTelefono(),
                    c.getCorreo(),
                    c.getDireccion(),
                    c.getEstado()
            });
        }
    }

    // GUARDAR
    public void guardar() {
        if (vista.txtNombre.getText().trim().isEmpty()
                || vista.txtDocumento.getText().trim().isEmpty()
                || vista.txtTelefono.getText().trim().isEmpty()
                || vista.txtCorreo.getText().trim().isEmpty()
                || vista.txtDireccion.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return;
        }

        if (!vista.txtCorreo.getText().contains("@")) {
            JOptionPane.showMessageDialog(null, "Correo inválido");
            return;
        }

        cliente.setNombre(vista.txtNombre.getText());
        cliente.setDocumento(vista.txtDocumento.getText());
        cliente.setTelefono(vista.txtTelefono.getText());
        cliente.setCorreo(vista.txtCorreo.getText());
        cliente.setDireccion(vista.txtDireccion.getText());
        cliente.setEstado(vista.cbEstado.getSelectedItem().toString());

        dao.insertar(cliente, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Cliente registrado con éxito");
    }

    // CARGAR SELECCIÓN
    public void cargarSeleccion() {
        int fila = vista.tableCliente.getSelectedRow();
        if (fila < 0) return;

        vista.txtIdCliente.setText(vista.tableCliente.getValueAt(fila, 0).toString());
        vista.txtNombre.setText(vista.tableCliente.getValueAt(fila, 1).toString());
        vista.txtDocumento.setText(vista.tableCliente.getValueAt(fila, 2).toString());
        vista.txtTelefono.setText(vista.tableCliente.getValueAt(fila, 3).toString());
        vista.txtCorreo.setText(vista.tableCliente.getValueAt(fila, 4).toString());
        vista.txtDireccion.setText(vista.tableCliente.getValueAt(fila, 5).toString());
        vista.cbEstado.setSelectedItem(vista.tableCliente.getValueAt(fila, 6).toString());
    }

    // ACTUALIZAR
    public void actualizar() {
        if (vista.txtIdCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente primero");
            return;
        }

        cliente.setIdCliente(Integer.parseInt(vista.txtIdCliente.getText()));
        cliente.setNombre(vista.txtNombre.getText());
        cliente.setDocumento(vista.txtDocumento.getText());
        cliente.setTelefono(vista.txtTelefono.getText());
        cliente.setCorreo(vista.txtCorreo.getText());
        cliente.setDireccion(vista.txtDireccion.getText());
        cliente.setEstado(vista.cbEstado.getSelectedItem().toString());

        dao.actualizar(cliente, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Cliente actualizado");
    }

    // ELIMINAR
    public void eliminar() {
        if (vista.txtIdCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione un cliente");
            return;
        }

        if (JOptionPane.showConfirmDialog(null,
                "¿Eliminar este cliente?", "Confirmación",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            dao.eliminar(Integer.parseInt(vista.txtIdCliente.getText()), usuarioLogueado);
            listar();
            limpiar();
        }
    }

    // LIMPIAR
    public void limpiar() {
        vista.txtIdCliente.setText("");
        vista.txtNombre.setText("");
        vista.txtDocumento.setText("");
        vista.txtTelefono.setText("");
        vista.txtCorreo.setText("");
        vista.txtDireccion.setText("");
        vista.txtBuscar.setText("");
        vista.cbEstado.setSelectedIndex(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) guardar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnLimpiar) limpiar();

        if (e.getSource() == vista.btnVolver) {
            vista.dispose();
            principal.setVisible(true);
        }
    }
}
