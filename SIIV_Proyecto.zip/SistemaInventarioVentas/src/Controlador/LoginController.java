/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.UsuarioDAO;
import Modelo.Usuario;
import Vista.FrmLogin;
import Vista.FrmPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class LoginController implements ActionListener {

    FrmLogin vista;
    UsuarioDAO usuarioDAO = new UsuarioDAO();

    public LoginController(FrmLogin v) {
        this.vista = v;
        vista.btnIngresar.addActionListener(this);
        vista.lblMensaje.setVisible(false);
    }

    // INICIO
    public void iniciar() {
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }

    // VALIDAR LOGIN
    private void validarLogin() {
        String usuario = vista.txtUsuario.getText().trim();
        String clave = String.valueOf(vista.txtContrasena.getPassword()).trim();

        if (usuario.isEmpty() || clave.isEmpty()) {
            vista.lblMensaje.setText("Debe completar todos los campos");
            vista.lblMensaje.setVisible(true);
            return;
        }

        Usuario u = usuarioDAO.login(usuario, clave);

        if (u != null) {
            abrirPrincipal(u);
            vista.dispose();
        } else {
            vista.lblMensaje.setText("Credenciales incorrectas");
            vista.lblMensaje.setVisible(true);
        }
    }

    // ABRIR PANTALLA PRINCIPAL
    private void abrirPrincipal(Usuario usuarioLogueado) {
        FrmPrincipal principal = new FrmPrincipal();
        PrincipalController pc = new PrincipalController(principal, usuarioLogueado);

        principal.lblUsuarioActivo.setText("Usuario: " + usuarioLogueado.getNombreUsuario());
        principal.lblRolActivo.setText("Rol: " + obtenerNombreRol(usuarioLogueado.getIdRol()));

        aplicarPermisos(principal, usuarioLogueado.getIdRol());
        principal.setLocationRelativeTo(null);
        principal.setVisible(true);
    }

    // NOMBRE DEL ROL
    private String obtenerNombreRol(int idRol) {
        return switch (idRol) {
            case 1 ->
                "Administrador";
            case 2 ->
                "Vendedor";
            case 3 ->
                "Analista";
            default ->
                "Desconocido";
        };
    }

    // PERMISOS POR ROL
    private void aplicarPermisos(FrmPrincipal principal, int idRol) {

        switch (idRol) {

            case 1: // Administrador - acceso total
                principal.btnUsuarios.setEnabled(true);
                principal.btnProductos.setEnabled(true);
                principal.btnClientes.setEnabled(true);
                principal.btnProveedores.setEnabled(true);
                principal.btnCategorias.setEnabled(true);
                principal.btnCompras.setEnabled(true);
                principal.btnVentas.setEnabled(true);
                break;

            case 2: // Vendedor
                principal.btnUsuarios.setEnabled(false);
                principal.btnProductos.setEnabled(true);
                principal.btnClientes.setEnabled(true);
                principal.btnProveedores.setEnabled(true);
                principal.btnCategorias.setEnabled(true);
                principal.btnCompras.setEnabled(false);
                principal.btnVentas.setEnabled(true);
                break;

            case 3: // Analista - solo CONSULTA
                principal.btnUsuarios.setEnabled(false);
                principal.btnProductos.setEnabled(false);
                principal.btnClientes.setEnabled(false);
                principal.btnProveedores.setEnabled(false);
                principal.btnCategorias.setEnabled(false);
                principal.btnCompras.setEnabled(true);
                principal.btnVentas.setEnabled(true);
                break;
        }
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnIngresar) {
            validarLogin();
        }
    }
}
