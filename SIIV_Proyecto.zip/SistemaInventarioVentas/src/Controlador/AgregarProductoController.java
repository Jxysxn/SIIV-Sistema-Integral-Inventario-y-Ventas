/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Vista.DlgAgregarProducto;
import Vista.FrmCompra;
import DAO.ProductoDAO;
import Modelo.Producto;
import Modelo.Usuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AgregarProductoController implements ActionListener {

    private DlgAgregarProducto vista;
    private FrmCompra vistaCompra;
    private DefaultTableModel modeloTabla;
    private ProductoDAO productoDAO = new ProductoDAO();
    private Usuario usuarioLogueado;

    public AgregarProductoController(DlgAgregarProducto v, FrmCompra compra,
                                     DefaultTableModel modelo, Usuario usuario) {

        this.vista = v;
        this.vistaCompra = compra;
        this.modeloTabla = modelo;
        this.usuarioLogueado = usuario;

        vista.btnAgregar.addActionListener(this);
        vista.btnCancelar.addActionListener(this);
        vista.cbProducto.addActionListener(this);

        cargarProductos();
    }

    // CARGAR PRODUCTOS EN COMBO
    private void cargarProductos() {
        vista.cbProducto.removeAllItems();

        for (Producto p : productoDAO.listar(usuarioLogueado)) {
            vista.cbProducto.addItem(p.getNombre());
        }

        if (vista.cbProducto.getItemCount() > 0) {
            vista.cbProducto.setSelectedIndex(0);
            cargarPrecio();
        }
    }

    // CARGAR PRECIO UNITARIO
    private void cargarPrecio() {
        if (vista.cbProducto.getSelectedItem() == null) return;

        String nombre = vista.cbProducto.getSelectedItem().toString();
        Producto p = productoDAO.buscarPorNombre(nombre, usuarioLogueado);

        if (p != null) {
            vista.txtPrecioUnitario.setText(String.valueOf(p.getPrecioCompra()));
        }
    }

    // AGREGAR PRODUCTO A LA TABLA
    private void agregarProducto() {

        try {
            String producto = vista.cbProducto.getSelectedItem().toString();
            int cantidad = Integer.parseInt(vista.txtCantidad.getText());
            double precio = Double.parseDouble(vista.txtPrecioUnitario.getText());
            double subtotal = cantidad * precio;

            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser mayor a 0");
                return;
            }

            modeloTabla.addRow(new Object[]{
                producto,
                cantidad,
                precio,
                subtotal
            });

            vista.dispose();
            vistaCompra.txtTotal.setText(calcularTotal());

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese valores numéricos válidos");
        }
    }

    // CALCULAR TOTAL
    private String calcularTotal() {
        double total = 0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            total += Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());
        }
        return String.valueOf(total);
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.cbProducto) {
            cargarPrecio();
        }

        if (e.getSource() == vista.btnAgregar) {
            agregarProducto();
        }

        if (e.getSource() == vista.btnCancelar) {
            vista.dispose();
        }
    }
}
