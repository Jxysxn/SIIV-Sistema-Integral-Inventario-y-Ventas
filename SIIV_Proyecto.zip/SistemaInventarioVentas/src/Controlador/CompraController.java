/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.CompraDAO;
import DAO.DetalleCompraDAO;
import DAO.ProductoDAO;
import DAO.ProveedorDAO;

import Modelo.DetalleCompra;
import Modelo.Proveedor;
import Modelo.Usuario;

import Vista.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class CompraController implements ActionListener {

    private FrmCompra vista;
    private FrmPrincipal principal;
    private Usuario usuarioLogueado;

    private DefaultTableModel modeloTabla = new DefaultTableModel();

    private CompraDAO compraDAO = new CompraDAO();
    private DetalleCompraDAO detalleDAO = new DetalleCompraDAO();
    private ProveedorDAO proveedorDAO = new ProveedorDAO();
    private ProductoDAO productoDAO = new ProductoDAO();

    public CompraController(FrmCompra v, FrmPrincipal p, Usuario usuario) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuario;

        vista.lblUsuarioActivo.setText("Usuario: " + usuario.getNombreUsuario());

        vista.btnVolver.addActionListener(this);
        vista.btnAgregarProducto.addActionListener(this);
        vista.btnEliminarDetalle.addActionListener(this);
        vista.btnConsultarCompras.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);

        configurarTabla();
        cargarProveedores();
        inicializarCabecera();

        aplicarPermisos();
    }

    // 🔐 PERMISOS SEGÚN ROL
    private void aplicarPermisos() {
        if (usuarioLogueado.getIdRol() == 3) {  // ANALISTA
            vista.btnAgregarProducto.setEnabled(false);
            vista.btnEliminarDetalle.setEnabled(false);
            vista.btnGuardar.setEnabled(false);
            vista.btnLimpiar.setEnabled(false);
        }
    }

    private void configurarTabla() {
        modeloTabla = (DefaultTableModel) vista.tableDetalleCompra.getModel();
        modeloTabla.setRowCount(0);
        vista.tableDetalleCompra.setModel(modeloTabla);
    }

    private void cargarProveedores() {
        vista.cbProveedor.removeAllItems();
        for (Proveedor p : proveedorDAO.listarActivos(usuarioLogueado)) {
            vista.cbProveedor.addItem(p.getIdProveedor() + " - " + p.getNombre());
        }
        vista.cbProveedor.setEnabled(usuarioLogueado.getIdRol() != 3); // Deshabilitar para analista
    }

    private void inicializarCabecera() {
        vista.txtFecha.setText(LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        vista.txtFecha.setEnabled(false);

        String numero = compraDAO.generarNumeroFactura(usuarioLogueado);
        if (numero == null || numero.trim().isEmpty()) {
            numero = "000001";
        }

        vista.txtNumFactura.setText(numero);
        vista.txtNumFactura.setEnabled(false);
    }

    private void calcularTotal() {
        double total = 0;
        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            total += Double.parseDouble(modeloTabla.getValueAt(i, 3).toString());
        }
        vista.txtTotal.setText(String.valueOf(total));
    }

    private void limpiar() {
        modeloTabla.setRowCount(0);
        vista.txtTotal.setText("");
        if (vista.cbProveedor.getItemCount() > 0) {
            vista.cbProveedor.setSelectedIndex(0);
        }
        inicializarCabecera();
    }

    private void guardarCompra() {
        if (usuarioLogueado.getIdRol() == 3) {
            JOptionPane.showMessageDialog(null, "No tiene permisos para registrar compras.");
            return;
        }

        if (modeloTabla.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "Debe agregar productos antes de guardar.");
            return;
        }

        String item = vista.cbProveedor.getSelectedItem().toString();
        int idProveedor = Integer.parseInt(item.split(" - ")[0]);

        int idCompra = compraDAO.registrarCompra(idProveedor, usuarioLogueado.getIdUsuario(), usuarioLogueado);

        if (idCompra <= 0) {
            JOptionPane.showMessageDialog(null, "Error al registrar la compra en la base de datos.");
            return;
        }

        for (int i = 0; i < modeloTabla.getRowCount(); i++) {
            DetalleCompra d = new DetalleCompra();
            d.setIdCompra(idCompra);
            d.setIdProducto(productoDAO.obtenerIdProductoPorNombre(modeloTabla.getValueAt(i, 0).toString(), usuarioLogueado));
            d.setCantidad(Integer.parseInt(modeloTabla.getValueAt(i, 1).toString()));
            d.setPrecioUnitario(Double.parseDouble(modeloTabla.getValueAt(i, 2).toString()));
            detalleDAO.registrarDetalle(d, usuarioLogueado);
        }

        JOptionPane.showMessageDialog(null, "Compra registrada con éxito.");
        limpiar();
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.btnVolver) {
            principal.setVisible(true);
            vista.dispose();
        }

        if (e.getSource() == vista.btnAgregarProducto) {
            if (usuarioLogueado.getIdRol() == 3) return;
            DlgAgregarProducto dlg = new DlgAgregarProducto(vista, true);
            new AgregarProductoController(dlg, vista, modeloTabla, usuarioLogueado);
            dlg.setVisible(true);
        }

        if (e.getSource() == vista.btnEliminarDetalle) {
            if (usuarioLogueado.getIdRol() == 3) return;
            int fila = vista.tableDetalleCompra.getSelectedRow();
            if (fila >= 0) {
                modeloTabla.removeRow(fila);
                calcularTotal();
            } else {
                JOptionPane.showMessageDialog(null, "Seleccione un item primero.");
            }
        }

        if (e.getSource() == vista.btnConsultarCompras) {
            FrmCompraConsulta frm = new FrmCompraConsulta();
            new CompraConsultaController(frm, vista, usuarioLogueado);
            frm.setVisible(true);
            vista.setVisible(false);
        }

        if (e.getSource() == vista.btnGuardar) {
            guardarCompra();
        }

        if (e.getSource() == vista.btnLimpiar) {
            if (usuarioLogueado.getIdRol() != 3) limpiar();
        }
    }
}
