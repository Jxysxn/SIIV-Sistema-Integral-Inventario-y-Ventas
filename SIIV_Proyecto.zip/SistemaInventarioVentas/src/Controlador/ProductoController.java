/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.ProductoDAO;
import DAO.CategoriaDAO;
import DAO.ProveedorDAO;

import Modelo.Producto;
import Modelo.Usuario;

import Vista.FrmProducto;
import Vista.FrmPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ProductoController implements ActionListener {

    FrmProducto vista;
    FrmPrincipal principal;
    Usuario usuarioLogueado;

    ProductoDAO productoDAO = new ProductoDAO();
    CategoriaDAO categoriaDAO = new CategoriaDAO();
    ProveedorDAO proveedorDAO = new ProveedorDAO();

    Producto producto = new Producto();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public ProductoController(FrmProducto v, FrmPrincipal p, Usuario usuario) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuario;

        // Eventos botones
        vista.btnGuardar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnVolver.addActionListener(this);

        // Click en tabla
        vista.tableProducto.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarSeleccion();
            }
        });

        // Buscador dinámico
        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        // Estados
        vista.cbEstado.removeAllItems();
        vista.cbEstado.addItem("Activo");
        vista.cbEstado.addItem("Inactivo");

        vista.txtIdProducto.setEditable(false);

        // Cargar datos iniciales
        listar();
        cargarCategorias();
        cargarProveedores();

        // Aplicar permisos según rol (analista solo consulta)
        aplicarPermisosPorRol();
    }

    // PERMISOS POR ROL
    private void aplicarPermisosPorRol() {
        if (usuarioLogueado == null) return;

        int rol = usuarioLogueado.getIdRol();
        // 1 = Admin, 2 = Vendedor, 3 = Analista (solo lectura)
        if (rol == 3) {
            vista.btnGuardar.setEnabled(false);
            vista.btnActualizar.setEnabled(false);
            vista.btnEliminar.setEnabled(false);
        }
    }

    // LISTAR
    private void listar() {
        modeloTabla = (DefaultTableModel) vista.tableProducto.getModel();
        modeloTabla.setRowCount(0);

        for (Producto p : productoDAO.listar(usuarioLogueado)) {
            String nombreCategoria = categoriaDAO.obtenerNombreCategoria(p.getIdCategoria(), usuarioLogueado);
            String nombreProveedor = proveedorDAO.obtenerNombreProveedor(p.getIdProveedor(), usuarioLogueado);

            modeloTabla.addRow(new Object[]{
                p.getIdProducto(),
                p.getNombre(),
                p.getDescripcion(),
                p.getPrecioCompra(),
                p.getPrecioVenta(),
                p.getStock(),
                p.getEstado(),
                nombreCategoria,
                nombreProveedor
            });
        }
    }

    // CARGAR COMBOS
    private void cargarCategorias() {
        vista.cbCategoria.removeAllItems();
        categoriaDAO.listar(usuarioLogueado).forEach(c -> {
            vista.cbCategoria.addItem(c.getNombre());
        });
    }

    private void cargarProveedores() {
        vista.cbProveedor.removeAllItems();
        proveedorDAO.listar(usuarioLogueado).forEach(p -> {
            vista.cbProveedor.addItem(p.getNombre());
        });
    }

    // BÚSQUEDA AVANZADA
    private void buscar() {
        String criterio = vista.txtBuscar.getText().trim().toLowerCase();
        if (criterio.isEmpty()) {
            listar();
            return;
        }

        modeloTabla.setRowCount(0);

        for (Producto p : productoDAO.listar(usuarioLogueado)) {

            String nombreCategoria = categoriaDAO.obtenerNombreCategoria(p.getIdCategoria(), usuarioLogueado);
            String nombreProveedor = proveedorDAO.obtenerNombreProveedor(p.getIdProveedor(), usuarioLogueado);

            String idStr = String.valueOf(p.getIdProducto());
            String compraStr = String.valueOf(p.getPrecioCompra());
            String ventaStr = String.valueOf(p.getPrecioVenta());
            String stockStr = String.valueOf(p.getStock());

            // Coincidencia en cualquier campo visible de la tabla
            boolean coincide =
                    idStr.contains(criterio)
                    || p.getNombre().toLowerCase().contains(criterio)
                    || (p.getDescripcion() != null && p.getDescripcion().toLowerCase().contains(criterio))
                    || compraStr.contains(criterio)
                    || ventaStr.contains(criterio)
                    || stockStr.contains(criterio)
                    || p.getEstado().toLowerCase().contains(criterio)
                    || (nombreCategoria != null && nombreCategoria.toLowerCase().contains(criterio))
                    || (nombreProveedor != null && nombreProveedor.toLowerCase().contains(criterio));

            if (coincide) {
                modeloTabla.addRow(new Object[]{
                    p.getIdProducto(),
                    p.getNombre(),
                    p.getDescripcion(),
                    p.getPrecioCompra(),
                    p.getPrecioVenta(),
                    p.getStock(),
                    p.getEstado(),
                    nombreCategoria,
                    nombreProveedor
                });
            }
        }
    }

    // CARGAR SELECCIÓN
    private void cargarSeleccion() {
        int fila = vista.tableProducto.getSelectedRow();
        if (fila < 0) {
            return;
        }

        vista.txtIdProducto.setText(vista.tableProducto.getValueAt(fila, 0).toString());
        vista.txtNombre.setText(vista.tableProducto.getValueAt(fila, 1).toString());
        vista.txtDescripcion.setText(vista.tableProducto.getValueAt(fila, 2).toString());
        vista.txtPrecioCompra.setText(vista.tableProducto.getValueAt(fila, 3).toString());
        vista.txtPrecioVenta.setText(vista.tableProducto.getValueAt(fila, 4).toString());
        vista.txtStock.setText(vista.tableProducto.getValueAt(fila, 5).toString());
        vista.cbEstado.setSelectedItem(vista.tableProducto.getValueAt(fila, 6).toString());
        vista.cbCategoria.setSelectedItem(vista.tableProducto.getValueAt(fila, 7).toString());
        vista.cbProveedor.setSelectedItem(vista.tableProducto.getValueAt(fila, 8).toString());
    }

    // VALIDACIONES COMUNES
    private boolean validarCamposBasicos() {
        if (vista.txtNombre.getText().trim().isEmpty()
                || vista.txtDescripcion.getText().trim().isEmpty()
                || vista.txtPrecioCompra.getText().trim().isEmpty()
                || vista.txtPrecioVenta.getText().trim().isEmpty()
                || vista.txtStock.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(null,
                    "Todos los campos son obligatorios.",
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (vista.cbCategoria.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null,
                    "Debe seleccionar una categoría.",
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (vista.cbProveedor.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null,
                    "Debe seleccionar un proveedor.",
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    private boolean cargarNumericosDesdeFormulario() {
        try {
            double compra = Double.parseDouble(vista.txtPrecioCompra.getText().trim());
            double venta = Double.parseDouble(vista.txtPrecioVenta.getText().trim());
            int stock = Integer.parseInt(vista.txtStock.getText().trim());

            if (compra < 0 || venta < 0) {
                JOptionPane.showMessageDialog(null,
                        "Los precios no pueden ser negativos.",
                        "Validación",
                        JOptionPane.WARNING_MESSAGE);
                return false;
            }

            if (venta < compra) {
                JOptionPane.showMessageDialog(null,
                        "El precio de venta debe ser mayor o igual al precio de compra.",
                        "Validación",
                        JOptionPane.WARNING_MESSAGE);
                return false;
            }

            if (stock < 0) {
                JOptionPane.showMessageDialog(null,
                        "El stock no puede ser negativo.",
                        "Validación",
                        JOptionPane.WARNING_MESSAGE);
                return false;
            }

            // Si todo bien, cargar al modelo
            producto.setPrecioCompra(compra);
            producto.setPrecioVenta(venta);
            producto.setStock(stock);

            return true;

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null,
                    "Precios y stock deben ser valores numéricos válidos.",
                    "Error de formato",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }

    private void cargarModeloDesdeFormulario() {
        producto.setNombre(vista.txtNombre.getText().trim());
        producto.setDescripcion(vista.txtDescripcion.getText().trim());
        producto.setEstado(vista.cbEstado.getSelectedItem().toString());

        String nombreCategoria = vista.cbCategoria.getSelectedItem().toString();
        String nombreProveedor = vista.cbProveedor.getSelectedItem().toString();

        int idCategoria = categoriaDAO.obtenerIdCategoria(nombreCategoria, usuarioLogueado);
        int idProveedor = proveedorDAO.obtenerIdProveedor(nombreProveedor, usuarioLogueado);

        producto.setIdCategoria(idCategoria);
        producto.setIdProveedor(idProveedor);
    }

    // GUARDAR
    private void guardar() {
        // Analista no debe poder guardar
        if (usuarioLogueado.getIdRol() == 3) {
            JOptionPane.showMessageDialog(null,
                    "No tiene permisos para registrar productos (rol analista).");
            return;
        }

        if (!validarCamposBasicos()) return;
        if (!cargarNumericosDesdeFormulario()) return;

        cargarModeloDesdeFormulario();

        boolean ok = productoDAO.insertar(producto, usuarioLogueado);

        if (ok) {
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Producto registrado con éxito");
        } else {
            JOptionPane.showMessageDialog(null,
                    "Error al registrar el producto. Revise la consola/log para más detalles.");
        }
    }

    // ACTUALIZAR
    private void actualizar() {
        if (usuarioLogueado.getIdRol() == 3) {
            JOptionPane.showMessageDialog(null,
                    "No tiene permisos para actualizar productos (rol analista).");
            return;
        }

        if (vista.txtIdProducto.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Seleccione un producto para actualizar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!validarCamposBasicos()) return;
        if (!cargarNumericosDesdeFormulario()) return;

        producto.setIdProducto(Integer.parseInt(vista.txtIdProducto.getText().trim()));
        cargarModeloDesdeFormulario();

        boolean ok = productoDAO.actualizar(producto, usuarioLogueado);

        if (ok) {
            listar();
            limpiar();
            JOptionPane.showMessageDialog(null, "Producto actualizado");
        } else {
            JOptionPane.showMessageDialog(null,
                    "Error al actualizar el producto. Revise la consola/log para más detalles.");
        }
    }

    // ELIMINAR
    private void eliminar() {
        if (usuarioLogueado.getIdRol() == 3) {
            JOptionPane.showMessageDialog(null,
                    "No tiene permisos para eliminar productos (rol analista).");
            return;
        }

        if (vista.txtIdProducto.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null,
                    "Seleccione un producto para eliminar.",
                    "Advertencia",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                null,
                "¿Eliminar producto seleccionado?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            int id = Integer.parseInt(vista.txtIdProducto.getText().trim());
            boolean ok = productoDAO.eliminar(id, usuarioLogueado);

            if (ok) {
                listar();
                limpiar();
                JOptionPane.showMessageDialog(null, "Producto eliminado");
            } else {
                JOptionPane.showMessageDialog(null,
                        "Error al eliminar producto. Puede ser restricción de claves foráneas o permisos.");
            }
        }
    }

    // LIMPIAR
    private void limpiar() {
        vista.txtIdProducto.setText("");
        vista.txtNombre.setText("");
        vista.txtDescripcion.setText("");
        vista.txtPrecioCompra.setText("");
        vista.txtPrecioVenta.setText("");
        vista.txtStock.setText("");
        vista.txtBuscar.setText("");
        vista.cbEstado.setSelectedIndex(0);
        if (vista.cbCategoria.getItemCount() > 0) vista.cbCategoria.setSelectedIndex(0);
        if (vista.cbProveedor.getItemCount() > 0) vista.cbProveedor.setSelectedIndex(0);
    }

    // EVENTOS
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) guardar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnLimpiar) limpiar();

        if (e.getSource() == vista.btnVolver) {
            vista.dispose();
            principal.setVisible(true);
        }
    }
}
