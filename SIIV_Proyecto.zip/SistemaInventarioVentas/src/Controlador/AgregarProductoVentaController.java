/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.ProductoDAO;
import Modelo.Producto;
import Modelo.Usuario;
import Vista.DlgAgregarProductoVenta;
import Vista.FrmVenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AgregarProductoVentaController implements ActionListener {

    private DlgAgregarProductoVenta vista;
    private FrmVenta vistaVenta;
    private DefaultTableModel modeloTabla;
    private Usuario usuarioLogueado;
    private VentaController ventaController;

    private ProductoDAO productoDAO = new ProductoDAO();

    public AgregarProductoVentaController(DlgAgregarProductoVenta v, FrmVenta venta,
            DefaultTableModel modelo, Usuario usuario, VentaController controller) {

        this.vista = v;
        this.vistaVenta = venta;
        this.modeloTabla = modelo;
        this.usuarioLogueado = usuario;
        this.ventaController = controller;

        vista.btnAgregar.addActionListener(this);
        vista.btnCancelar.addActionListener(this);
        vista.cbProducto.addActionListener(this);

        cargarProductos();
    }

    private void cargarProductos() {
        vista.cbProducto.removeAllItems();

        for (Producto p : productoDAO.listar(usuarioLogueado)) {
            if ("Activo".equalsIgnoreCase(p.getEstado()) && p.getStock() > 0) {
                vista.cbProducto.addItem(p.getNombre());
            }
        }

        if (vista.cbProducto.getItemCount() > 0) {
            vista.cbProducto.setSelectedIndex(0);
            cargarDatosProducto();
        }
    }

    private void cargarDatosProducto() {
        if (vista.cbProducto.getSelectedItem() == null) {
            return;
        }

        String nombre = vista.cbProducto.getSelectedItem().toString();
        Producto p = productoDAO.buscarPorNombre(nombre, usuarioLogueado);

        if (p != null) {
            vista.txtStockDisponible.setText(String.valueOf(p.getStock()));
            vista.txtPrecioUnitario.setText(String.valueOf(p.getPrecioVenta()));
        }
    }

    private void agregarProducto() {
        try {
            if (vista.cbProducto.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(null, "Debe seleccionar un producto.");
                return;
            }

            String producto = vista.cbProducto.getSelectedItem().toString();

            int cantidad = Integer.parseInt(vista.txtCantidad.getText());
            int stock = Integer.parseInt(vista.txtStockDisponible.getText());
            double precio = Double.parseDouble(vista.txtPrecioUnitario.getText());

            if (cantidad <= 0) {
                JOptionPane.showMessageDialog(null, "La cantidad debe ser mayor a 0");
                return;
            }

            if (cantidad > stock) {
                JOptionPane.showMessageDialog(null, "Cantidad supera el stock disponible");
                return;
            }

            double subtotal = cantidad * precio;

            modeloTabla.addRow(new Object[]{
                producto,
                cantidad,
                precio,
                subtotal
            });

            // recalcular totales en el controlador principal
            ventaController.recalcularTotales();

            vista.dispose();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese valores numéricos válidos.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.cbProducto) {
            cargarDatosProducto();
        }

        if (e.getSource() == vista.btnAgregar) {
            agregarProducto();
        }

        if (e.getSource() == vista.btnCancelar) {
            vista.dispose();
        }
    }
}
