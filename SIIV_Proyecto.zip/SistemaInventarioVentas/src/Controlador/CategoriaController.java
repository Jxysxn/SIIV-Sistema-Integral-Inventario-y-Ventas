/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import DAO.CategoriaDAO;
import Modelo.Categoria;
import Modelo.Usuario;
import Vista.FrmCategoria;
import Vista.FrmPrincipal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CategoriaController implements ActionListener {

    FrmCategoria vista;
    FrmPrincipal principal;
    Usuario usuarioLogueado;

    CategoriaDAO dao = new CategoriaDAO();
    Categoria categoria = new Categoria();
    DefaultTableModel modeloTabla = new DefaultTableModel();

    public CategoriaController(FrmCategoria v, FrmPrincipal p, Usuario usuario) {
        this.vista = v;
        this.principal = p;
        this.usuarioLogueado = usuario;

        vista.btnGuardar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
        vista.btnVolver.addActionListener(this);

        vista.tableCategoria.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cargarSeleccion();
            }
        });

        vista.txtBuscar.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                buscar();
            }
        });

        vista.cbEstado.removeAllItems();
        vista.cbEstado.addItem("Activo");
        vista.cbEstado.addItem("Inactivo");
        vista.txtIdCategoria.setEditable(false);

        listar();
    }

    // LISTAR
    public void listar() {
        modeloTabla = (DefaultTableModel) vista.tableCategoria.getModel();
        modeloTabla.setRowCount(0);

        for (Categoria c : dao.listar(usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                c.getIdCategoria(),
                c.getNombre(),
                c.getDescripcion(),
                c.getEstado()
            });
        }
    }

    // BUSCAR
    public void buscar() {
        String criterio = vista.txtBuscar.getText().trim();

        if (criterio.isEmpty()) {
            listar();
            return;
        }

        modeloTabla.setRowCount(0);

        for (Categoria c : dao.buscar(criterio, usuarioLogueado)) {
            modeloTabla.addRow(new Object[]{
                c.getIdCategoria(),
                c.getNombre(),
                c.getDescripcion(),
                c.getEstado()
            });
        }
    }

    // GUARDAR
    public void guardar() {
        if (vista.txtNombre.getText().trim().isEmpty()
                || vista.txtDescripcion.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios.");
            return;
        }

        categoria.setNombre(vista.txtNombre.getText());
        categoria.setDescripcion(vista.txtDescripcion.getText());
        categoria.setEstado(vista.cbEstado.getSelectedItem().toString());

        dao.insertar(categoria, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Categoría registrada con éxito");
    }

    // CARGAR SELECCIÓN
    public void cargarSeleccion() {
        int fila = vista.tableCategoria.getSelectedRow();
        if (fila < 0) return;

        vista.txtIdCategoria.setText(vista.tableCategoria.getValueAt(fila, 0).toString());
        vista.txtNombre.setText(vista.tableCategoria.getValueAt(fila, 1).toString());
        vista.txtDescripcion.setText(vista.tableCategoria.getValueAt(fila, 2).toString());
        vista.cbEstado.setSelectedItem(vista.tableCategoria.getValueAt(fila, 3).toString());
    }

    // ACTUALIZAR
    public void actualizar() {
        if (vista.txtIdCategoria.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una categoría");
            return;
        }

        categoria.setIdCategoria(Integer.parseInt(vista.txtIdCategoria.getText()));
        categoria.setNombre(vista.txtNombre.getText());
        categoria.setDescripcion(vista.txtDescripcion.getText());
        categoria.setEstado(vista.cbEstado.getSelectedItem().toString());

        dao.actualizar(categoria, usuarioLogueado);
        listar();
        limpiar();
        JOptionPane.showMessageDialog(null, "Categoría actualizada con éxito");
    }

    // ELIMINAR
    public void eliminar() {
        if (vista.txtIdCategoria.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seleccione una categoría");
            return;
        }

        if (JOptionPane.showConfirmDialog(null, "¿Eliminar categoría?", "Confirmación",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

            dao.eliminar(Integer.parseInt(vista.txtIdCategoria.getText()), usuarioLogueado);
            listar();
            limpiar();
        }
    }

    public void limpiar() {
        vista.txtIdCategoria.setText("");
        vista.txtNombre.setText("");
        vista.txtDescripcion.setText("");
        vista.txtBuscar.setText("");
        vista.cbEstado.setSelectedIndex(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnGuardar) guardar();
        if (e.getSource() == vista.btnActualizar) actualizar();
        if (e.getSource() == vista.btnEliminar) eliminar();
        if (e.getSource() == vista.btnLimpiar) limpiar();

        if (e.getSource() == vista.btnVolver) {
            vista.dispose();
            principal.setVisible(true);
        }
    }
}
