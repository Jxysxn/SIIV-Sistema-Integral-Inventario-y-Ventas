/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static Connection con = null;

    public static Connection getConexion(String user, String password) {

        try {
            // Si existe una conexión previa, cerrarla antes de crear otra
            if (con != null && !con.isClosed()) {
                con.close();
            }

            String url = "jdbc:mysql://localhost:3306/SistemaInventarioVentas"
                    + "?useSSL=false&serverTimezone=UTC&noAccessToProcedureBodies=true";

            con = DriverManager.getConnection(url, user, password);
            System.out.println(" Conexion establecida con usuario: " + user);

        } catch (SQLException e) {
            System.out.println(" Error en la conexion: " + e.getMessage());
        }

        return con;
    }
}
